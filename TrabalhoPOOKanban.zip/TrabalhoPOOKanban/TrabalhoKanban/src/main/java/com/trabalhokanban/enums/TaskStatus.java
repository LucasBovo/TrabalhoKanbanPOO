package com.trabalhokanban.enums;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}