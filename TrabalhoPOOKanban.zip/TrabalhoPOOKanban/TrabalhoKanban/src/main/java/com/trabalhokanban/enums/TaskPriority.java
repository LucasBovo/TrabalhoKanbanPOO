package com.trabalhokanban.enums;

public enum TaskPriority {
    LOW,
    MEDIUM,
    HIGH
}